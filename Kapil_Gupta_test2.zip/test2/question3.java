package test2;

public class question3 {
    public static void maxWindowElement(int[] nums, int k){
        int n = nums.length;
        for(int i = 0; i <= n - 3; i++){
            int max = Integer.MIN_VALUE;
            for(int j = i; j < i + 3; j++){
                if(nums[j] > max){
                    max = nums[j];
                }
            }
            System.out.print(max + " ");
        }
    }

    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 1, 4, 5, 2, 3, 6};
        int k = 3;

        maxWindowElement(nums, k);
    }
}
