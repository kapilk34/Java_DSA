package test2;

public class question5 {
    public static int maxNumber(int[] nums, int target){
        int left = 0;
        int right = nums.length - 1;
        int result = Integer.MIN_VALUE;

        while(left <= right){
            int mid = left + (right - left) / 2;
            if(nums[mid] <= target){
                result = mid;
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return result;
    }
    public static void main(String[] args) {
        int[] nums = {1,2,8,10,12,19};
        int target = 5;

        int index = maxNumber(nums, target);
        System.out.print(index);
    }
}
