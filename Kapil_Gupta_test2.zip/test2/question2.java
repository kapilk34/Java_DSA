package test2;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class question2 {
    public static Node IntersectingNode(Node head1, Node head2) {
        Node fast = head1;
        Node slow = head2;
        int lengthA = 0;
        while (fast != null) {
            lengthA++;
            fast = fast.next;
        }
        int lengthB = 0;
        while (slow != null) {
            lengthB++;
            slow = slow.next;
        }
        fast = head1;
        slow = head2;
        if (lengthA > lengthB) {
            int steps = lengthA - lengthB;
            for (int i = 0; i < steps; i++) {
                fast = fast.next;
            }
        } else {
            int steps = lengthB - lengthA;
            for (int i = 0; i < steps; i++) {
                slow = slow.next;
            }
        }
        while (fast != slow) {
            fast = fast.next;
            slow = slow.next;
        }
        return fast;
    }

    public static void main(String[] args) {
        Node common = new Node(15);
        common.next = new Node(30);
        Node head1 = new Node(10);
        head1.next = common;

        Node head2 = new Node(3);
        head2.next = new Node(6);
        head2.next.next = new Node(9);
        head2.next.next.next = common;

        IntersectingNode(head1, head2);
    }
}
