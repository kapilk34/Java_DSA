package test;

public class question1 {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5};
        int[] b = {1, 2, 3, 6, 7};
        int[] c = new int[a.length + b.length];
        int i = 0, j = 0, k = 0;

        while(i < a.length && j <b.length){
            if(a[i] < b[j]){
                c[k] = a[i];
                i++;
                k++;
            }
            else{
                c[k] = b[j];
                j++;
                k++;
            }
            if(i == a.length){
                c[k] = b[j];
                j++;
                k++;
            }
            if(j == b.length){
                c[k] = a[i];
                i++;
                k++;
            }    
        }
        for(int num : c){
            System.out.print(num + " ");
        }
    }
}
