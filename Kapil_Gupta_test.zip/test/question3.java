int class{
    int data;
    Node null;

    Node(int data){
        this.data = data;
        this.next = null;
    }
}

public class question3 {
    public static void sum(Node data, int[] nums1, int nums2){

    }
    public static void main(String[] args) {
        int[] nums1 = {1,2,3};
        int[] nums2 = {9,9,9};

    }
}
