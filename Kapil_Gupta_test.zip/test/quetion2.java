package test;

import java.util.*;

public class quetion2 {
    public static void Foursum(int[] nums, int target){
        //Four Sum: Two pointer
        List<List<List>> result = new List<List<List>>();

        int n = nums.length;

        for(int i = 0; i < n; i++){
            if(i > 0 && nums[i] == nums[i - 1]) continue;
            for(int j = i + 1; j < n; j++){
                if(j > i + 1 && nums[j] == nums[j - 1]) continue;
                int start = j + 1;
                int end = n - 1;
                while(start < end){
                    int sum = nums[i] + nums[j] + nums[start] + nums[end];

                    if(sum == target){
                        result.add(Arrays.asList(Arrays.asList((long)nums[i], (long)nums[j], (long)nums[start], (long)nums[end])));

                        while(start < end && nums[start] == nums[start + 1]) start++;
                        while(start < end && nums[end] == nums[end - 1]) end--;

                        start++;
                        end--;
                    }
                    else if(sum < target){
                        start++;
                    }
                    else{
                        end--;
                    }
                }    
            }
        }
        return result;
    }
    public static void main(String[] args) {
        int[] nums = {1,0,-1,0,-2,2};
        int target = 0;
        Foursum(nums, target);
    }
}
