package test;

import java.util.*;

public class question4 {
    //stack
    public static void Evaluation(int Stack){
        Stack<Integer> st = new Stack<>();
        int n = nums.length;

        while(!Stack.isEmpty() && nums[stack.peek()] <= nums[i]){
            st.pop();
        }

    }

    public static void main(String[] args) {
        char[] nums = {2,3,1,*,+,9};
        Evaluation(nums);
    }

}
