package test;

import java.util.Arrays;

public class question5 {
    //sliding window
    public static int[] nonNegative(int[] arr, int k){
        int n = arr.length;
        int[] ans = new int[n-1];
        for(int i = 0; i < n; i++){
            if(arr[i] < 0){
                ans[i] = arr[i];
            }
            else{
                arr[i] = 0;
            }
        }
        for(int j = 1; j < k; j++ ){
            arr[0] += arr[j];
            k++;
        }
        return ans;
    }
    public static void main(String[] args) {
        int[] arr = {-8,2,3,-6,10};
        int k = 2;
        System.out.println(Arrays.toString(nonNegative(arr, k)));
    }
}
